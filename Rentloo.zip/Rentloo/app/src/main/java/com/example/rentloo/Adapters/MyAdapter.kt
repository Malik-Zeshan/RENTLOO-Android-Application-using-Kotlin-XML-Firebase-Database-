package com.example.rentloo.Adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.rentloo.DetailActivity
import com.example.rentloo.Modules.UserProducts
import com.example.rentloo.R
import com.google.android.material.imageview.ShapeableImageView

class MyAdapter(private val context: Context, private val productList: ArrayList<UserProducts>):
    RecyclerView.Adapter<MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view:View = LayoutInflater.from(parent.context).inflate(R.layout.rcv_items_linear, parent, false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = productList[position]
        Glide.with(context).load(currentItem.image).into(holder.itemImg)
        holder.itemName.text = currentItem.name
        holder.itemPrice.text = "${currentItem.rent_rate} $/hr"
        holder.itemLocation.text = currentItem.city
        holder.itemDate.text = currentItem.date
        holder.descripton.text = currentItem.description

        holder.recCardLinear.setOnClickListener{
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("image", productList[holder.adapterPosition].image)
            intent.putExtra("name", productList[holder.adapterPosition].name)
            intent.putExtra("price", productList[holder.adapterPosition].rent_rate)
            intent.putExtra("date", productList[holder.adapterPosition].date)
            intent.putExtra("location", productList[holder.adapterPosition].city)
            intent.putExtra("description", productList[holder.adapterPosition].description)
            context.startActivity(intent)
        }
    }
}
class MyViewHolder(itemView:View): RecyclerView.ViewHolder(itemView){
    var itemImg: ImageView
    var itemLocation: TextView
    var itemName: TextView
    var itemPrice: TextView
    var itemDate: TextView
    var recCardLinear:CardView
    var descripton: TextView
    init {
        itemImg= itemView.findViewById(R.id.imageViewItem)
        itemName= itemView.findViewById(R.id.textViewItemName)
        itemPrice= itemView.findViewById(R.id.textViewItemPrice)
        itemLocation = itemView.findViewById(R.id.textViewItemLocation)
        itemDate= itemView.findViewById(R.id.textViewItemDate)
        recCardLinear = itemView.findViewById(R.id.recCardLinear)
        descripton= itemView.findViewById(R.id.tvdescription)
    }
}