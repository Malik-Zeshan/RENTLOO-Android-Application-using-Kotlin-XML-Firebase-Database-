package com.example.rentloo.Fragments

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.rentloo.Adapters.MyAdapter
import com.example.rentloo.Adapters.rcvAdapterLinear
import com.example.rentloo.LoginActivity
import com.example.rentloo.Modules.UserProducts
import com.example.rentloo.Modules.Userdata
import com.example.rentloo.Modules.product
import com.example.rentloo.Modules.rcvItems
import com.example.rentloo.R
import com.example.rentloo.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage


class ProfileFragment : Fragment() {
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference
    private lateinit var storageReference: StorageReference
    private lateinit var binding: FragmentProfileBinding
    private lateinit var uid:String

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentProfileBinding.inflate(inflater, container, false)
        firebaseAuth = FirebaseAuth.getInstance()
        storageReference = Firebase.storage.reference
        uid = firebaseAuth.currentUser!!.uid.toString()

        binding.btnLogout.setOnClickListener{
            logout()
        }

        if (uid.isNotEmpty()){
            getUserData()
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        initializer()
        yourProducts()
    }

    private fun logout() {
        firebaseAuth.signOut()
        val intent = Intent(activity,LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }
    private fun getUserData(){
        databaseReference = Firebase.database.getReference("Users")
        databaseReference.child(uid).addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val user = snapshot.getValue(Userdata::class.java)
                Glide.with(activity!!).load(user!!.imageUrl).into(binding.profileImage)
                binding.tvUserName.text = user?.name
                binding.tvUserEmail.text = user?.email
                binding.tvUserContact.text = user?.contact
                binding.tvUserCity.text = user?.city
                binding.tvUserCountry.text = user?.country
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
    }
    private fun yourProducts(){
        var yourProducts: ArrayList<UserProducts>
        yourProducts = ArrayList()
        val recyclerViewYourProducts = binding.recyclerViewYourProducts

        databaseReference = FirebaseDatabase.getInstance().getReference("Products").child(uid)

        recyclerViewYourProducts.layoutManager = LinearLayoutManager(requireActivity(), LinearLayoutManager.VERTICAL, false)

        var adapter: MyAdapter = MyAdapter(requireActivity(), yourProducts)
        recyclerViewYourProducts.adapter = adapter

        databaseReference.addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                yourProducts.clear()
                if (snapshot.exists()) {
                    for (productsnap in snapshot.children) {
                        val prod = productsnap.getValue(UserProducts::class.java)
                        yourProducts.add(prod!!)
                    }
                }

                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
    }

}