package com.example.rentloo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.example.rentloo.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonLogin.setOnClickListener {
            loginUser()
        }

        binding.textViewSignUpLogin.setOnClickListener {
            startActivity(Intent(this, RegistrationActivity::class.java))
        }
    }

    private fun loginUser() {
        val password = binding.inputFieldPasswordLogin.text.toString()
        val email = binding.inputfieldEmailPhone.text.toString()

        when{
            password.isEmpty() || email.isEmpty() -> Toast.makeText(this, "Fill all the fields", Toast.LENGTH_SHORT)
                .show()
            else -> {
                val firebaseAuth:FirebaseAuth = FirebaseAuth.getInstance()
                firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(this) {task->
                    if(task.isSuccessful){
                        Toast.makeText(this, "Login Successful ", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, MainActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        finish()
                    } else{
                        Toast.makeText(this, task.exception!!.toString(), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}