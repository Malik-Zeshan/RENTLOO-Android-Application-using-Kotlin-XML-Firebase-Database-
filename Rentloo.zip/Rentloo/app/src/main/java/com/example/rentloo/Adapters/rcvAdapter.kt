package com.example.rentloo.Adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.rentloo.DetailActivity
import com.example.rentloo.Modules.UserProducts
import com.example.rentloo.Modules.product
import com.example.rentloo.Modules.rcvItems
import com.example.rentloo.R
import com.google.android.material.imageview.ShapeableImageView

class rcvAdapterLinear(var context: Context, val itemDetails: ArrayList<product>):
        RecyclerView.Adapter<rcvAdapterLinear.itemViewHolder>(){
//    private var onItemClickListener: ((product)->Unit)? = null
        inner class itemViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
            val itemImg: ImageView = itemView.findViewById(R.id.imageViewItem)
            val itemName: TextView = itemView.findViewById(R.id.textViewItemName)
            val itemPrice: TextView = itemView.findViewById(R.id.textViewItemPrice)
            val itemLocation: TextView = itemView.findViewById(R.id.textViewItemLocation)
            val itemDate: TextView = itemView.findViewById(R.id.textViewItemDate)
            val description:TextView = itemView.findViewById(R.id.tvdescription)
            val recCard:CardView = itemView.findViewById(R.id.recCardLinear)
            val renttime:TextView = itemView.findViewById(R.id.tvrenttime)
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): itemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.rcv_items_linear, parent, false)
        return itemViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemDetails.size
    }

    override fun onBindViewHolder(holder: itemViewHolder, position: Int) {
        val currentItem = itemDetails[position]
        Glide.with(context).load(currentItem.image).into(holder.itemImg)
        holder.itemName.text = currentItem.name
        holder.itemPrice.text = "${currentItem.rent_rate} $/hr"
        holder.itemLocation.text = currentItem.city
        holder.itemDate.text = currentItem.date
        holder.description.text = currentItem.description
        holder.renttime.text = currentItem.rent_time

        holder.recCard.setOnClickListener{
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("image", itemDetails[holder.adapterPosition].image)
            intent.putExtra("name", itemDetails[holder.adapterPosition].name)
            intent.putExtra("price", itemDetails[holder.adapterPosition].rent_rate)
            intent.putExtra("date", itemDetails[holder.adapterPosition].date)
            intent.putExtra("location", itemDetails[holder.adapterPosition].city)
            intent.putExtra("description", itemDetails[holder.adapterPosition].description)
            intent.putExtra("rentTime",itemDetails[holder.adapterPosition].rent_time)
            context.startActivity(intent)
        }
    }
}
//--------------------------------------------------------------------------------------------------
class rcvAdapterGrid(val itemDetails: ArrayList<rcvItems>):
    RecyclerView.Adapter<rcvAdapterGrid.itemViewHolder>(){
    private var onItemClickListener: ((rcvItems)->Unit)? = null
    inner class itemViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        val itemImg: ShapeableImageView = itemView.findViewById(R.id.imageViewItem)
        val itemName: TextView = itemView.findViewById(R.id.textViewItemName)
        val itemPrice: TextView = itemView.findViewById(R.id.textViewItemPrice)
        val itemLocation: TextView = itemView.findViewById(R.id.textViewItemLocation)
        val itemDate: TextView = itemView.findViewById(R.id.textViewItemDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): itemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.rcv_items_grid, parent, false)
        return itemViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemDetails.size
    }

    override fun onBindViewHolder(holder: itemViewHolder, position: Int) {
        val currentItem = itemDetails[position]
        holder.itemImg.setImageResource(currentItem.img)
        holder.itemName.text = currentItem.name
        holder.itemPrice.text = currentItem.price
        holder.itemLocation.text = currentItem.location
        holder.itemDate.text = currentItem.date

        holder.itemView.setOnClickListener{
            onItemClickListener?.invoke(currentItem)
        }
    }
}
//--------------------------------------------------------------------------------------------------

/*class rcvAdapterLinear(val itemDetails: ArrayList<rcvItems>):
        RecyclerView.Adapter<rcvAdapterLinear.itemViewHolder>(){
    private var onItemClickListener: ((rcvItems)->Unit)? = null
            inner class itemViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
                val itemImg: ShapeableImageView = itemView.findViewById(R.id.imageViewItem)
                val itemName: TextView = itemView.findViewById(R.id.textViewItemName)
                val itemPrice: TextView = itemView.findViewById(R.id.textViewItemPrice)
                val itemLocation: TextView = itemView.findViewById(R.id.textViewItemLocation)
                val itemDate: TextView = itemView.findViewById(R.id.textViewItemDate)
            }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): itemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.rcv_items_linear, parent, false)
        return itemViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemDetails.size
    }

    override fun onBindViewHolder(holder: itemViewHolder, position: Int) {
        val currentItem = itemDetails[position]
        holder.itemImg.setImageResource(currentItem.img)
        holder.itemName.text = currentItem.name
        holder.itemPrice.text = currentItem.price
        holder.itemLocation.text = currentItem.location
        holder.itemDate.text = currentItem.date

        holder.itemView.setOnClickListener{
            onItemClickListener?.invoke(currentItem)
        }
    }
}*/
