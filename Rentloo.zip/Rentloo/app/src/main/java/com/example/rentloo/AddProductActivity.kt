package com.example.rentloo

import android.annotation.SuppressLint
import android.app.Dialog
import android.icu.util.LocaleData
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.example.rentloo.Modules.AddProcuctDetail
import com.example.rentloo.databinding.ActivityAddProductBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import java.lang.System.currentTimeMillis
import java.time.LocalDate

class AddProductActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddProductBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firebaseDatabase: DatabaseReference
    private lateinit var firebaseUser: FirebaseUser
    private lateinit var storage: StorageReference
    private lateinit var imageUri: Uri
    private lateinit var uid:String
    private lateinit var dialog: Dialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddProductBinding.inflate(layoutInflater)
        setContentView(binding.root)
        storage = Firebase.storage.reference
        firebaseDatabase = Firebase.database.reference
        firebaseAuth = FirebaseAuth.getInstance()
        firebaseUser = firebaseAuth.currentUser!!
        uid = firebaseUser.uid

        val pickMedia = registerForActivityResult(ActivityResultContracts.PickVisualMedia()){uri->
            imageUri = uri!!
            binding.imageView.setImageURI(uri)}

        binding.imageView.setOnClickListener{
            pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

        binding.buttonPostItem.setOnClickListener{

          if(binding.imageView.drawable == null ){
                  Toast.makeText(this, " Please Upload An Image", Toast.LENGTH_SHORT).show()
              }else{
                  uploadImage()
              }
        }
    }
    @SuppressLint("SuspiciousIndentation")
    private fun uploadImage(){
        showProgressBar()
//        storage = FirebaseStorage.getInstance()
        // Create a storage reference from our app
//        var storageRef = storage.reference.child("Product Images").child(uid).putFile(imageUri).addOnCompleteListener{
        var storageRef = storage.child("Product Images/$uid").child(currentTimeMillis().toString())
//        storage.child("Product Images/$uid").child(currentTimeMillis().toString())
            storageRef.putFile(imageUri).addOnCompleteListener{ task ->
            if(task.isSuccessful){
                storageRef.downloadUrl.addOnSuccessListener { uri->
                    val mapImage = HashMap<String, String>()
                    mapImage["image"] = uri.toString()
                    uploadProduct(mapImage["image"])
                }
                hideProgressBar()
                Toast.makeText(this, "Upload successful", Toast.LENGTH_SHORT).show()
            }else{
                hideProgressBar()
                Toast.makeText(this, "Upload Failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @SuppressLint("NewApi")
    private fun uploadProduct(url: String?) {
        val imageUrl = url
        val name = binding.edittextItemName.text.toString()
        val rent_rate = binding.edittextHourlyrate.text.toString()
        val rent_time = binding.inputfieldRentduration.text.toString()
        val description = binding.inputfieldDescription.text.toString()
        val city = binding.inputFieldCity.text.toString()
        val date = LocalDate.now().toString()

        if (name.isEmpty()||rent_time.isEmpty()||rent_rate.isEmpty()||description.isEmpty()||city.isEmpty()){
            Toast.makeText(this, "Fill All The Fields", Toast.LENGTH_SHORT).show()
        }else{
            val product = AddProcuctDetail(imageUrl, name, rent_rate, rent_time, description, city, date)
            firebaseDatabase.child("Products").child(uid).push().setValue(product)
        }
    }

    private fun showProgressBar(){
        dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_box_progressbar)
        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }
    private fun hideProgressBar(){
        dialog.dismiss()
    }
}

