package com.example.rentloo.Modules

class UserProducts {
    var image: String? = null
    private set
    var city: String? = null
    private set
    var description: String? = null
    private set
    var name: String? = null
    private set
    var rent_rate: String? = null
    private set
    var rent_time: String? = null
    private set
    var date: String? = null
    private set

    private constructor(){}

    constructor(
        image: String?,
        city: String?,
        description: String?,
        name: String?,
        rent_time: String?,
        rent_rate: String?,
        date: String?
    ) {
        this.image = image
        this.city = city
        this.description = description
        this.name = name
        this.rent_rate = rent_rate
        this.rent_time = rent_time
        this.date = date
    }
}