package com.example.rentloo.Modules

import android.os.Parcel
import android.os.Parcelable

data class rcvItems(
    val img:Int,
    val name: String?,
    val price:String?,
    val location:String?,
    val date:String?
): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(img)
        parcel.writeString(name)
        parcel.writeString(price)
        parcel.writeString(location)
        parcel.writeString(date)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<rcvItems> {
        override fun createFromParcel(parcel: Parcel): rcvItems {
            return rcvItems(parcel)
        }

        override fun newArray(size: Int): Array<rcvItems?> {
            return arrayOfNulls(size)
        }
    }
}
