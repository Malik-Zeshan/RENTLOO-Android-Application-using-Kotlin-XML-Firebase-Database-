package com.example.rentloo

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.service.autofill.UserData
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.example.rentloo.Modules.Userdata
import com.example.rentloo.databinding.ActivityRegistrationBinding
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage

class RegistrationActivity : AppCompatActivity() {
    private lateinit var binding:ActivityRegistrationBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firebaseUser: FirebaseUser
    private lateinit var database: DatabaseReference
    private lateinit var storageReference: StorageReference
    private lateinit var userData:Userdata
    private lateinit var imageUri:Uri
    private lateinit var uid:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistrationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        firebaseAuth = FirebaseAuth.getInstance()
        firebaseUser= firebaseAuth.currentUser!!
        database = Firebase.database.reference

        val pickMedia = registerForActivityResult(ActivityResultContracts.PickVisualMedia()){ uri->
            imageUri = uri!!
            binding.profileimage.setImageURI(uri)}

        binding.profileimage.setOnClickListener {
            pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

        binding.buttonSignUp.setOnClickListener {
            uploadImge()
            registerUser()
        }
        binding.textViewLoginReg.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }

    private var imgurl:String? = null
    private fun uploadImge() {
        uid = firebaseAuth.currentUser!!.uid
        storageReference = Firebase.storage.reference.child("Profile Images").child(uid)
        storageReference.putFile(imageUri).addOnCompleteListener() {task->
            if (task.isSuccessful){
                storageReference.downloadUrl.addOnSuccessListener { uri->
                    val mapImage = HashMap<String, String>()
                    mapImage["image"] = uri.toString()
                    imgurl = mapImage["image"]
                }
            }
        }
    }

    private fun registerUser(url: String? = imgurl){

        val imageUrl = url
        val name = binding.edittextName.text.toString()
        val password = binding.inputFieldPasswordReg.text.toString()
        val email = binding.edittextEmail.text.toString()
        val contact = binding.inputfieldContact.text.toString()
        val country = binding.inputfieldCountry.text.toString()
        val city = binding.inputFieldCity.text.toString()
        when {
            name.isEmpty()||password.isEmpty()||email.isEmpty()||contact.isEmpty()||country.isEmpty()||
                city.isEmpty() -> {
                Toast.makeText(this, "Fill All the fields", Toast.LENGTH_SHORT).show()
                }
            else ->{
                firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(
                    OnCompleteListener { task ->
                        if(task.isSuccessful){
//                            val fireBaseUser: FirebaseUser = task.result!!.user!!     //Note: this and the below line have the same functionality
//                            firebaseUser= firebaseAuth.currentUser!!
                            val uid = firebaseAuth.currentUser!!.uid
                            userData = Userdata(name, password,email,contact, country,city, imageUrl)
//                            database = Firebase.database.reference
                            database.child("Users").child(uid).setValue(userData)

                            Toast.makeText(this, "Register Successfully", Toast.LENGTH_SHORT).show()

                            val intent =  Intent(this, LoginActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            startActivity(intent)
                            finish()

                        }
                        else{
                            Toast.makeText(this, task.exception!!.message.toString(), Toast.LENGTH_SHORT).show()
                        }
                    }

                )
            }
        }


    }
}