package com.example.rentloo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.rentloo.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding:ActivityDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bundle = intent.extras
        if (bundle != null){
            binding.tvname.text = bundle.getString("name")
            binding.price.text = bundle.getString("price") +"$/hr"
            binding.tvCity.text = bundle.getString("location")
            binding.tvrenttime.text = bundle.getString("date")
            binding.tvdescriptionitem.text = bundle.getString("description")
            Glide.with(this).load(bundle.getString("image")).into(binding.ivItem)
        }
    }
}