package com.example.rentloo.Modules

import android.net.Uri

data class AddProcuctDetail(
    var image:String? = null,
    var name:String? = null,
    var rent_rate:String? = null,
    var rent_time:String? = null,
    var description:String? = null,
    var city:String? = null,
    var date:String? = null
)
