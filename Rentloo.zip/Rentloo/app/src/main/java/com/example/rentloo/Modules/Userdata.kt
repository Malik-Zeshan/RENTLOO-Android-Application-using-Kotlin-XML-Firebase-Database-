package com.example.rentloo.Modules

data class Userdata(
    val name:String? = null,
    val password:String? = null,
    val email:String? = null,
    val contact:String? = null,
    val country:String? = null,
    val city:String? = null,
    val imageUrl: String? = null
)
