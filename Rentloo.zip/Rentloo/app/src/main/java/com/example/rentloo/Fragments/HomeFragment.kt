package com.example.rentloo.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.rentloo.Adapters.rcvAdapterLinear
import com.example.rentloo.Adapters.rcvAdapterGrid
import com.example.rentloo.Modules.UserProducts
import com.example.rentloo.Modules.Userdata
import com.example.rentloo.Modules.product
import com.example.rentloo.Modules.rcvItems
import com.example.rentloo.R
import com.example.rentloo.databinding.FragmentHomeBinding
import com.example.rentloo.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage

class HomeFragment:Fragment() {
    private lateinit var firbaseDataBase: DatabaseReference
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var storageReference: StorageReference
    private lateinit var binding: FragmentHomeBinding
    private lateinit var uid:String
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        firebaseAuth = FirebaseAuth.getInstance()
        storageReference = Firebase.storage.reference
        uid = firebaseAuth.currentUser!!.uid.toString()
        if (uid.isNotEmpty()){
            getUserData()
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initializer()
    }

   private fun initializer(){
        val featureProducts = ArrayList<product>()
        var yourProducts = ArrayList<product>()
        val recentProducts = ArrayList<rcvItems>()
        val recyclerViewFeaturedItems = view?.findViewById<RecyclerView>(R.id.recyclerViewFeaturedItems)
        val recyclerViewYourItems = view?.findViewById<RecyclerView>(R.id.recyclerViewYourItems)
        val recyclerViewRecentItems = view?.findViewById<RecyclerView>(R.id.recyclerViewRecentItems)

        recyclerViewFeaturedItems?.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL,false)
        firbaseDataBase = FirebaseDatabase.getInstance().getReference("Products")
        firbaseDataBase.addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()){
                    for(uidsnaps in snapshot.children){
                        for (productSnaps in uidsnaps.children) {
                            val prod = productSnaps.getValue(product::class.java)
                            featureProducts.add(prod!!)
                        }
                    }
                    recyclerViewFeaturedItems?.adapter =rcvAdapterLinear(requireActivity(),featureProducts)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })

//        featureProducts.add(rcvItems(R.drawable.image1,"abc","1234/hr","pak","6th"))
//        featureProducts.add(rcvItems(R.drawable.image2,"abc","1234/hr","pak","6th"))
//        featureProducts.add(rcvItems(R.drawable.image3,"abc","1234/hr","pak","6th"))
//        featureProducts.add(rcvItems(R.drawable.image4,"abc","1234/hr","pak","6th"))
//
//        recyclerViewFeaturedItems?.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL,false)
//        recyclerViewFeaturedItems?.adapter = rcvAdapterLinear(featureProducts)
//


       yourProducts = ArrayList()
       val recyclerViewAdapter = rcvAdapterLinear(requireActivity(), yourProducts)
       recyclerViewYourItems?.adapter = recyclerViewAdapter
       recyclerViewYourItems?.layoutManager = LinearLayoutManager(requireActivity(),LinearLayoutManager.HORIZONTAL, false)

       uid = Firebase.auth.currentUser!!.uid

       firbaseDataBase = Firebase.database.getReference("Products").child(uid)
       firbaseDataBase.addValueEventListener(object : ValueEventListener{
           override fun onDataChange(snapshot: DataSnapshot) {
               for (productsnap in snapshot.children) {
                   val prod = productsnap.getValue(product::class.java)
                   yourProducts.add(prod!!)
               }
               recyclerViewAdapter.notifyDataSetChanged()
           }

           override fun onCancelled(error: DatabaseError) {
               TODO("Not yet implemented")
           }

       })




        recentProducts.add(rcvItems(R.drawable.image10,"Axe","2000/hr","pak","6th"))
        recentProducts.add(rcvItems(R.drawable.image11,"Sword of Destruction","2000/hr","pak","6th"))
        recentProducts.add(rcvItems(R.drawable.image12,"Sword of Destruction","2000/hr","pak","6th"))
        recentProducts.add(rcvItems(R.drawable.image13,"Sword of Destruction","2000/hr","pak","6th"))
        recentProducts.add(rcvItems(R.drawable.image14,"Sword of Destruction","2000/hr","pak","6th"))
        recentProducts.add(rcvItems(R.drawable.image15,"Sword of Destruction","2000/hr","pak","6th"))


        recyclerViewRecentItems?.layoutManager = GridLayoutManager(activity, 2)
        recyclerViewRecentItems?.adapter = rcvAdapterGrid(recentProducts)
    }

    private fun getUserData(){
        firbaseDataBase = Firebase.database.getReference("Users")
        firbaseDataBase.child(uid).addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val user = snapshot.getValue(Userdata::class.java)
//                Glide.with(activity!!).load(user!!.imageUrl).into(binding.profileImage)
                binding.textView.text = "Welcome ${user?.name}"
//                binding.tvUserEmail.text = user?.email
//                binding.tvUserContact.text = user?.contact
//                binding.tvUserCity.text = user?.city
//                binding.tvUserCountry.text = user?.country
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
    }
}
