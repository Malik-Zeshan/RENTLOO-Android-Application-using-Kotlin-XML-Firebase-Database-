package com.example.rentloo.Modules

import android.os.Parcel
import android.os.Parcelable

//class product {
//    var image: String? = null
//    var city: String? = null
//    var description: String? = null
//    var name: String? = null
//    var rent_rate: String? = null
//    var rent_time: String? = null
//    var date: String? = null
//
//    constructor(
//        image: String?,
//        city: String?,
//        description: String?,
//        name: String?,
//        rent_time: String?,
//        rent_rate: String?,
//        date: String?
//    ) {
//        this.image = image
//        this.city = city
//        this.description = description
//        this.name = name
//        this.rent_rate = rent_rate
//        this.rent_time = rent_time
//        this.date = date
//    }
//    constructor(){
//
//    }
//}

data class product(
    var image:String? = null,
    var city:String? = null,
    var description:String? = "",
    var name:String? = null,
    var rent_rate:String? = null,
    var rent_time:String? = null,
    var date:String?= ""
):Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(image)
        parcel.writeString(city)
        parcel.writeString(description)
        parcel.writeString(name)
        parcel.writeString(rent_rate)
        parcel.writeString(rent_time)
        parcel.writeString(date)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<product> {
        override fun createFromParcel(parcel: Parcel): product {
            return product(parcel)
        }

        override fun newArray(size: Int): Array<product?> {
            return arrayOfNulls(size)
        }
    }
}
